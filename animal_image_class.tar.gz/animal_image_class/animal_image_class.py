######################################################################################
# Autor: Wagner Machado do Amaral
# Data: 28/05/2018
# Descricao: Algoritmo para classificar animais em imagens.
# Testes foram realizados com os seguintes animais:
# * cat
# * dog
# * fish
# * giraffe
# * human
# * lion
# * sheep
#
# Referencias:
#  * Joe Minichino e Joseph Howse. Learning OpenCV 3 Computer Vision with Python
# 
######################################################################################

import cv2
import numpy as np
import os
from time import gmtime, strftime

training_dir_original = "/home/wagner/python/animal_image_class/01-TrainingImages/"
training_dir = "/home/wagner/python/animal_image_class/02-PreProcessingTrainingImages/"
test_dir_original = "/home/wagner/python/animal_image_class/03-TestImages/"
test_dir = "/home/wagner/python/animal_image_class/04-PreProcessingTestImages/"
result_dir = "/home/wagner/python/animal_image_class/05-ResultImages/"
label = ['cat','giraffe','human','lion']
label = sorted(label)

print(strftime("%Y-%m-%d %H:%M:%S", gmtime()))

detect = cv2.xfeatures2d.SURF_create(400)

extract = cv2.xfeatures2d.SURF_create(400)

flann_params = dict(algorithm = 1, trees = 5)
flann = cv2.FlannBasedMatcher(flann_params, {})

bow_kmeans_trainer = cv2.BOWKMeansTrainer(40)
extract_bow = cv2.BOWImgDescriptorExtractor(extract, flann)

def extract_surf(fn):
    im = cv2.imread(fn,0)
    return extract.compute(im, detect.detect(im))[1]

def bow_features(fn):
    im = cv2.imread(fn,0)
    return extract_bow.compute(im, detect.detect(im))

def predict(fn):
    f = bow_features(fn);
    p = svm.predict(f)
    return p


###################################################################################
print("\n*** PROCESSANDO IMAGENS DE TREINAMENTO E TESTE ***\n")
###################################################################################

for dir_name in sorted(os.listdir(training_dir_original)):
    for file_name in sorted(os.listdir(training_dir_original + dir_name)):
        # Processando imagens de treinamento
        source_image_in = training_dir_original + dir_name + "/" + file_name
        source_image_out = training_dir + dir_name + "/" + file_name
        img = cv2.imread(source_image_in)
        img = cv2.resize(img, (640,480), interpolation=cv2.INTER_AREA) 
        cv2.imwrite(source_image_out,img)
        print("\n")
        print(source_image_in)
        print(source_image_out)

for dir_name in sorted(os.listdir(test_dir_original)):
    for file_name in sorted(os.listdir(test_dir_original + dir_name)):
        # Processando imagens de treinamento
        source_image_in = test_dir_original + dir_name + "/" + file_name
        source_image_out = test_dir + dir_name + "/" + file_name
        img = cv2.imread(source_image_in)
        img = cv2.resize(img, (640,480), interpolation=cv2.INTER_AREA) 
        cv2.imwrite(source_image_out,img)
        print("\n")
        print(source_image_in)
        print(source_image_out)


###################################################################################
print("\n*** CONSTRUINDO VOCABULARIO ***\n")
###################################################################################

for dir_name in sorted(os.listdir(training_dir)):
    i = 0
    for file_name in sorted(os.listdir(training_dir + dir_name)):
        i = i + 1
        if (i<=10):
            source_image = training_dir + dir_name + "/" + file_name
            print(source_image)
            bow_kmeans_trainer.add(extract_surf(source_image))
        else:
            break

voc = bow_kmeans_trainer.cluster()
extract_bow.setVocabulary( voc )


###################################################################################
print("\n*** TREINANDO SVM ***\n")
###################################################################################

traindata, trainlabels = [],[]

label_num = -1
for dir_name in sorted(os.listdir(training_dir)):
    label_num = label_num + 1
    for file_name in os.listdir(training_dir + dir_name):
        source_image = training_dir + dir_name + "/" + file_name
        print(source_image)
        traindata.extend(bow_features(source_image));
        trainlabels.append(label_num)
        print(label_num)
        

svm = cv2.ml.SVM_create()
svm.train(np.array(traindata), cv2.ml.ROW_SAMPLE,
np.array(trainlabels))


###################################################################################
print("\n*** TESTANDO O CLASSIFICADOR ***\n")
###################################################################################

for dir_name in sorted(os.listdir(test_dir)):
    for file_name in os.listdir(test_dir + dir_name):
        source_image = test_dir + dir_name + "/" + file_name
        print("\n"+source_image)
        img = cv2.imread(source_image)
        predict_img = predict(source_image)
        font = cv2.FONT_HERSHEY_SIMPLEX
        cv2.putText(img,label[predict_img[1][0][0].astype(int)] ,(10,30), font,1,(0,255,0),2,cv2.LINE_AA)
        print(label[predict_img[1][0][0].astype(int)])
        cv2.imwrite(result_dir+file_name,img)

print(strftime("%Y-%m-%d %H:%M:%S", gmtime()))


